﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class MyEnum
    {
        public enum ContractTypePrice { Hours, Monthes }
        public enum dayes { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday }
        public enum YesNo { Yes, No } //didnt use it yet:)

    }
}
