﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace BL
{
    public class BL_Factory
    {
        //private static BL_Basic factory = null;
        //private BL_Factory() { }
        //public static IBL GetBLInstance()
        //{
        //    if (null == factory)
        //    {
        //        factory = new BL_Basic();
        //    }
        //    return factory;
        //}
    }
}
