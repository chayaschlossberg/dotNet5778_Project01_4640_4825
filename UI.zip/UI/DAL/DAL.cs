﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    class DAL
    {
        //public class DAL_Factory
        //{
        //    private static Dal_XML factory = null;
        //    private DAL_Factory() { }
        //    public static IDAL GetDalInstance()
        //    {
        //        if (null == factory)
        //        {
        //            factory = new Dal_XML();
        //        }
        //        return factory;
        //    }
        //}
    }
}
